
'use client';

import Image from 'next/image';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useState, useMemo, useEffect } from 'react';

import { Button } from '@/components/ui/button';
import { PlaceHolderImages } from '@/lib/placeholder-images';
import { Logo } from '@/components/logo';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { ArrowRight, Beer, LayoutGrid, Users, Monitor, Briefcase, Loader2 } from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Alert, AlertDescription } from '@/components/ui/alert';
import type { User } from '@/lib/types';

export default function LoginPage() {
  const loginImage = PlaceHolderImages.find((img) => img.id === 'login-bg');
  const [isPinDialogOpen, setIsPinDialogOpen] = useState(false);
  const [isCashierPinDialogOpen, setIsCashierPinDialogOpen] = useState(false);
  const [isBarmanPinDialogOpen, setIsBarmanPinDialogOpen] = useState(false);
  const [selectedUserId, setSelectedUserId] = useState<string | null>(null);
  const [pin, setPin] = useState('');
  const [pinError, setPinError] = useState<string | null>(null);
  const router = useRouter();

  const isUserLoading = false;

  // Fetch users from SQL API
  const [users, setUsers] = useState<User[]>([]);
  const [isLoadingUsers, setIsLoadingUsers] = useState(true);

  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const res = await fetch('/api/users');
        if (res.ok) {
          const data = await res.json();
          setUsers(data);
        }
      } catch (error) {
        console.error("Failed to fetch users", error);
      } finally {
        setIsLoadingUsers(false);
      }
    };
    fetchUsers();
  }, []);

  const activeWaiters = useMemo(() => users.filter(u => u.role.toLowerCase() === 'mozo' && u.status === 'Active'), [users]);
  const activeCashiers = useMemo(() => users.filter(u => u.role.toLowerCase() === 'cajero' && u.status === 'Active'), [users]);
  const activeBarmen = useMemo(() => users.filter(u => u.role.toLowerCase() === 'barman' && u.status === 'Active'), [users]);


  const handleProfileClick = (e: React.MouseEvent, profile: { href: string; action?: (e: React.MouseEvent) => void }) => {
    e.preventDefault();
    if (profile.action) {
      profile.action(e);
    } else {
      router.push(profile.href);
    }
  };

  // Auto-submit when PIN is 4 digits
  useEffect(() => {
    if (pin.length === 4) {
      if (isPinDialogOpen) handlePinSubmit('mozo', activeWaiters, setIsPinDialogOpen);
      if (isCashierPinDialogOpen) handlePinSubmit('cajero', activeCashiers, setIsCashierPinDialogOpen);
      if (isBarmanPinDialogOpen) handlePinSubmit('barman', activeBarmen, setIsBarmanPinDialogOpen);
    }
  }, [pin]);

  const handlePinSubmit = async (role: string, activeUsers: User[], setIsDialogOpen: (open: boolean) => void) => {
    if (!selectedUserId) {
      setPinError("Por favor, selecciona tu nombre.");
      return;
    }
    const user = (activeUsers || []).find(u => u.id === selectedUserId);

    if (!user) return;

    if (user.isLocked) {
      setPinError("Cuenta bloqueada. Contacte al administrador.");
      setPin('');
      return;
    }

    if (user.pin === pin) {
      // Success
      setPinError(null);
      setIsDialogOpen(false);

      // Reset failed attempts asynchronously
      try {
        await fetch(`/api/users/${user.id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ failedLoginAttempts: 0 })
        });
      } catch (e) { console.error(e); }

      const targetPath = role === 'mozo' ? '/waiter' : role === 'cajero' ? '/cashier' : '/bar';
      router.push(`${targetPath}?role=${role}&name=${encodeURIComponent(user.name)}&id=${user.id}`);
    } else {
      // Failure
      const newAttempts = (user.failedLoginAttempts || 0) + 1;
      const isNowLocked = newAttempts >= 3;

      try {
        await fetch(`/api/users/${user.id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            failedLoginAttempts: newAttempts,
            isLocked: isNowLocked
          })
        });

        // Update local state to reflect change immediately
        setUsers(prev => prev.map(u => u.id === user.id ? { ...u, failedLoginAttempts: newAttempts, isLocked: isNowLocked } : u));

      } catch (e) { console.error(e); }

      if (isNowLocked) {
        setPinError("Cuenta bloqueada por múltiples intentos fallidos. Contacte al administrador.");
      } else {
        setPinError("PIN incorrecto. Inténtalo de nuevo.");
      }
      setPin('');
    }
  };

  const handleWaiterLoginClick = (e: React.MouseEvent) => {
    setPinError(null);
    setPin('');
    setSelectedUserId(null);
    setIsPinDialogOpen(true);
  };

  const handleCashierLoginClick = (e: React.MouseEvent) => {
    setPinError(null);
    setPin('');
    setSelectedUserId(null);
    setIsCashierPinDialogOpen(true);
  };

  const handleBarmanLoginClick = (e: React.MouseEvent) => {
    setPinError(null);
    setPin('');
    setSelectedUserId(null);
    setIsBarmanPinDialogOpen(true);
  };

  // Wrapper functions for manual submit button (optional now due to auto-submit)
  const handleWaiterPinSubmit = () => handlePinSubmit('mozo', activeWaiters, setIsPinDialogOpen);
  const handleCashierPinSubmit = () => handlePinSubmit('cajero', activeCashiers, setIsCashierPinDialogOpen);
  const handleBarmanPinSubmit = () => handlePinSubmit('barman', activeBarmen, setIsBarmanPinDialogOpen);


  const profiles = [
    {
      href: '/dashboard?role=admin',
      icon: LayoutGrid,
      label: 'Admin',
      description: 'Acceso total al sistema y configuración.',
    },
    {
      href: '/dashboard?role=boss',
      icon: Briefcase,
      label: 'Jefe',
      description: 'Supervisión y reportes gerenciales.',
    },
    {
      href: '/cashier?role=cajero',
      icon: Monitor,
      label: 'Cajero',
      description: 'Acceso a la caja y transacciones.',
      action: handleCashierLoginClick,
    },
    {
      href: '/waiter?role=mozo',
      icon: Users,
      label: 'Mozo',
      description: 'Tomar pedidos y gestionar mesas.',
      action: handleWaiterLoginClick,
    },
    {
      href: '/bar?role=barman',
      icon: Beer,
      label: 'Barman',
      description: 'Gestionar pedidos de bebidas.',
      action: handleBarmanLoginClick,
    },
  ];

  if (isLoadingUsers || isUserLoading) {
    return (
      <div className="flex h-screen w-full items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <>
      <div className="w-full lg:grid lg:min-h-[100vh] lg:grid-cols-2 xl:min-h-[100vh]">
        <div className="flex items-center justify-center py-12">
          <div className="mx-auto grid w-[400px] gap-6 px-4">
            <div className="grid gap-2 text-center">
              <Logo className="mx-auto" />
              <h1 className="text-3xl font-bold">Seleccionar Perfil</h1>
              <p className="text-balance text-muted-foreground">
                Elige un perfil para simular el inicio de sesión.
              </p>
            </div>

            <div className="grid gap-4">
              {profiles.map((profile) => (
                <Card
                  key={profile.href}
                  className="hover:bg-muted/50 transition-colors cursor-pointer"
                  onClick={(e) => handleProfileClick(e, profile)}
                >
                  <CardHeader className="flex flex-row items-center gap-4 space-y-0 p-4">
                    <div className="bg-primary text-primary-foreground p-3 rounded-full">
                      <profile.icon className="h-6 w-6" />
                    </div>
                    <div className="flex-1">
                      <CardTitle className="text-lg">{profile.label}</CardTitle>
                      <CardDescription>{profile.description}</CardDescription>
                    </div>
                    <ArrowRight className="h-5 w-5 text-muted-foreground" />
                  </CardHeader>
                </Card>
              ))}
            </div>

            <div className="mt-4 text-center text-sm">
              Esto es una simulación.{' '}
              <Link href="#" className="underline">
                Aprende más
              </Link>
            </div>
          </div>
        </div>
        <div className="hidden bg-muted lg:block">
          {loginImage && (
            <Image
              src={loginImage.imageUrl}
              alt={loginImage.description}
              data-ai-hint={loginImage.imageHint}
              width="1920"
              height="1080"
              className="h-full w-full object-cover dark:brightness-[0.2] dark:grayscale"
            />
          )}
        </div>
      </div>
      {/* Waiter PIN Dialog */}
      <Dialog open={isPinDialogOpen} onOpenChange={setIsPinDialogOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Acceso de Mozo</DialogTitle>
            <DialogDescription>
              Selecciona tu nombre e ingresa tu PIN de 4 dígitos para continuar.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="waiter-select">Nombre del Mozo</Label>
              <Select onValueChange={setSelectedUserId} defaultValue={selectedUserId || ""}>
                <SelectTrigger id="waiter-select">
                  <SelectValue placeholder="Selecciona tu nombre" />
                </SelectTrigger>
                <SelectContent>
                  {(activeWaiters || []).map(waiter => (
                    <SelectItem key={waiter.id} value={waiter.id}>
                      <span>{waiter.name}</span>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="pin-waiter">PIN de Seguridad</Label>
              <Input
                id="pin-waiter"
                type="password"
                maxLength={4}
                value={pin}
                autoComplete="off"
                onChange={(e) => setPin(e.target.value)}
                className="text-center text-2xl tracking-[1rem]"
                placeholder="****"
              />
            </div>
            {pinError && (
              <Alert variant="destructive">
                <AlertDescription>{pinError}</AlertDescription>
              </Alert>
            )}
          </div>
          <DialogFooter>
            <Button type="submit" className="w-full" onClick={handleWaiterPinSubmit}>Ingresar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Cashier PIN Dialog */}
      <Dialog open={isCashierPinDialogOpen} onOpenChange={setIsCashierPinDialogOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Acceso de Cajero</DialogTitle>
            <DialogDescription>
              Selecciona tu nombre e ingresa tu PIN de 4 dígitos para continuar.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="cashier-select">Nombre del Cajero</Label>
              <Select onValueChange={setSelectedUserId} defaultValue={selectedUserId || ""}>
                <SelectTrigger id="cashier-select">
                  <SelectValue placeholder="Selecciona tu nombre" />
                </SelectTrigger>
                <SelectContent>
                  {(activeCashiers || []).map(cashier => (
                    <SelectItem key={cashier.id} value={cashier.id}>
                      <span>{cashier.name}</span>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="pin-cashier">PIN de Seguridad</Label>
              <Input
                id="pin-cashier"
                type="password"
                maxLength={4}
                value={pin}
                autoComplete="off"
                onChange={(e) => setPin(e.target.value)}
                className="text-center text-2xl tracking-[1rem]"
                placeholder="****"
              />
            </div>
            {pinError && (
              <Alert variant="destructive">
                <AlertDescription>{pinError}</AlertDescription>
              </Alert>
            )}
          </div>
          <DialogFooter>
            <Button type="submit" className="w-full" onClick={handleCashierPinSubmit}>Ingresar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Barman PIN Dialog */}
      <Dialog open={isBarmanPinDialogOpen} onOpenChange={setIsBarmanPinDialogOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Acceso de Barman</DialogTitle>
            <DialogDescription>
              Selecciona tu nombre e ingresa tu PIN de 4 dígitos para continuar.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="barman-select">Nombre del Barman</Label>
              <Select onValueChange={setSelectedUserId} defaultValue={selectedUserId || ""}>
                <SelectTrigger id="barman-select">
                  <SelectValue placeholder="Selecciona tu nombre" />
                </SelectTrigger>
                <SelectContent>
                  {(activeBarmen || []).map(barman => (
                    <SelectItem key={barman.id} value={barman.id}>
                      <span>{barman.name}</span>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="pin-barman">PIN de Seguridad</Label>
              <Input
                id="pin-barman"
                type="password"
                maxLength={4}
                value={pin}
                autoComplete="off"
                onChange={(e) => setPin(e.target.value)}
                className="text-center text-2xl tracking-[1rem]"
                placeholder="****"
              />
            </div>
            {pinError && (
              <Alert variant="destructive">
                <AlertDescription>{pinError}</AlertDescription>
              </Alert>
            )}
          </div>
          <DialogFooter>
            <Button type="submit" className="w-full" onClick={handleBarmanPinSubmit}>Ingresar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
