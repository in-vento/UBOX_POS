import Link from "next/link"

import { Button } from "@/components/ui/button"
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { PageHeader } from "@/components/page-header"
import { Label } from "@/components/ui/label"

export default function SettingsPage() {
  return (
    <>
      <PageHeader title="Configuración" description="Gestiona la configuración de tu cuenta y negocio." />
      <div className="grid gap-6 md:grid-cols-3">
        <div className="md:col-span-1">
          <Card>
            <CardHeader>
              <CardTitle>Plan Actual</CardTitle>
              <CardDescription>
                Actualmente estás en el plan Básico.
              </CardDescription>
            </CardHeader>
            <CardContent className="grid gap-4">
              <div className="space-y-1">
                <p className="font-medium">Plan Básico</p>
                <p className="text-sm text-muted-foreground">La licencia expira el 24 de Diciembre de 2024.</p>
              </div>
            </CardContent>
            <CardFooter>
              <Button className="w-full" asChild>
                <Link href="/pricing?role=admin">Administrar Suscripción</Link>
              </Button>
            </CardFooter>
          </Card>
        </div>
        <div className="md:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle>Información del Perfil</CardTitle>
              <CardDescription>
                Actualiza la información de tu cuenta.
              </CardDescription>
            </CardHeader>
            <CardContent className="grid gap-6">
              <div className="grid gap-2">
                <Label htmlFor="name">Nombre</Label>
                <Input id="name" defaultValue="Super Admin" />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="email">Email</Label>
                <Input id="email" type="email" defaultValue="admin@ubox.com" />
              </div>
            </CardContent>
            <CardFooter className="border-t pt-6">
              <Button>Guardar Cambios</Button>
            </CardFooter>
          </Card>
        </div>
      </div>
    </>
  )
}
