'use client';
import { useMemo } from 'react';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { Printer, Download, Package } from 'lucide-react';
import type { Product } from '@/lib/types';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';

type Beverage = Omit<Product, 'quantity'> & {
  stock: number;
  unit: 'bottles' | 'liters' | 'units';
};


type EndOfShiftReportDialogProps = {
  isOpen: boolean;
  onOpenChange: (isOpen: boolean) => void;
  inventory: Beverage[];
  onConfirm: (inventory: Beverage[]) => void;
};

export default function EndOfShiftReportDialog({
  isOpen,
  onOpenChange,
  inventory,
  onConfirm,
}: EndOfShiftReportDialogProps) {

  const handleDownloadPdf = () => {
    const input = document.getElementById('printable-shift-report');
    if (!input) return;

    // Clone and expand (similar to handlePrint)
    const clone = input.cloneNode(true) as HTMLElement;

    // Reset styles on the clone root
    clone.style.height = 'auto';
    clone.style.width = '600px'; // Fixed width for better PDF layout
    clone.style.overflow = 'visible';
    clone.style.maxHeight = 'none';
    clone.style.color = 'black';
    clone.style.backgroundColor = 'white';
    clone.style.position = 'absolute';
    clone.style.left = '-9999px';
    clone.style.top = '0';

    // Expand scrollable container
    const scrollContainer = clone.querySelector('.overflow-y-auto');
    if (scrollContainer) {
      const el = scrollContainer as HTMLElement;
      el.style.maxHeight = 'none';
      el.style.height = 'auto';
      el.style.overflow = 'visible';
      el.classList.remove('overflow-y-auto', 'max-h-[50vh]');
    }

    document.body.appendChild(clone);

    html2canvas(clone, {
      scale: 2,
      useCORS: true,
      windowWidth: 800
    }).then(canvas => {
      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF('p', 'mm', 'a4');
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = (canvas.height * pdfWidth) / canvas.width;

      // If content is very long, we might need multiple pages, but for now fitting to one or splitting image
      if (pdfHeight > pdf.internal.pageSize.getHeight()) {
        pdf.addImage(imgData, 'PNG', 10, 10, pdfWidth - 20, pdfHeight - 20);
      } else {
        pdf.addImage(imgData, 'PNG', 10, 10, pdfWidth - 20, pdfHeight - 20);
      }

      pdf.save(`reporte-inventario-bar.pdf`);

      if (document.body.contains(clone)) {
        document.body.removeChild(clone);
      }
    }).catch(err => {
      console.error("Error generating PDF:", err);
      if (document.body.contains(clone)) {
        document.body.removeChild(clone);
      }
    });
  };

  const handlePrint = () => {
    // Generate Ticket HTML structure directly from inventory data
    const ticketContent = document.createElement('div');
    ticketContent.innerHTML = `
        <div style="font-family: 'Courier New', monospace; width: 300px; margin: 0 auto; color: black; padding: 10px;">
            <div style="text-align: center; margin-bottom: 10px;">
                <h2 style="margin: 0; font-size: 1.2rem; font-weight: bold;">UBOX POS</h2>
                <p style="margin: 5px 0; font-size: 0.9rem;">REPORTE DE CIERRE (BAR)</p>
                <p style="margin: 5px 0; font-size: 0.8rem;">${new Date().toLocaleString('es-PE')}</p>
            </div>
            
            <hr style="border-top: 1px dashed black; margin: 10px 0;" />
            
            <div style="font-size: 0.85rem;">
                <div style="display: flex; justify-content: space-between; font-weight: bold; margin-bottom: 5px;">
                    <span>Producto</span>
                    <span>Stock</span>
                </div>
                ${inventory.map(item => `
                    <div style="display: flex; justify-content: space-between; margin-bottom: 3px;">
                        <span style="white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 200px;">${item.name}</span>
                        <span>${item.stock} ${item.unit === 'units' ? 'ud' : item.unit === 'bottles' ? 'bot' : 'lt'}</span>
                    </div>
                `).join('')}
            </div>
            
            <hr style="border-top: 1px dashed black; margin: 10px 0;" />
            
            <div style="margin-top: 30px; text-align: center;">
                <p style="font-size: 0.8rem;">Firma Responsable</p>
                <br/>
                <hr style="border-top: 1px solid black; width: 80%; margin: 0 auto;" />
            </div>
        </div>
    `;

    // Create a print container
    const printContainer = document.createElement('div');
    printContainer.id = 'print-container';
    printContainer.appendChild(ticketContent);
    document.body.appendChild(printContainer);

    // Add print styles
    const style = document.createElement('style');
    style.innerHTML = `
      @media print {
        body > *:not(#print-container) {
          display: none !important;
        }
        #print-container {
          display: block !important;
          position: absolute;
          top: 0;
          left: 0;
          width: 100%;
          height: auto;
          z-index: 9999;
          background-color: white;
        }
        #print-container * {
          visibility: visible !important;
          color: black !important;
        }
        @page {
          margin: 0;
          size: auto;
        }
      }
    `;
    document.head.appendChild(style);

    // Small delay to ensure DOM update before print
    setTimeout(() => {
      window.print();
    }, 100);

    const cleanup = () => {
      if (document.body.contains(printContainer)) {
        document.body.removeChild(printContainer);
      }
      if (document.head.contains(style)) {
        document.head.removeChild(style);
      }
    };

    window.addEventListener('afterprint', cleanup, { once: true });

    // Fallback cleanup
    setTimeout(cleanup, 2000);
  };


  if (!isOpen) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg">
        <div id="printable-shift-report" className="p-2">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Package className="h-6 w-6" />
              Reporte de Cierre de Turno (Bar)
            </DialogTitle>
            <DialogDescription>
              Resumen del inventario al momento del cierre. Verifica las cantidades antes de confirmar.
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <div className="max-h-[50vh] overflow-y-auto p-1 rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Bebida</TableHead>
                    <TableHead className="text-right">Stock Final</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {inventory.map((beverage) => (
                    <TableRow key={beverage.id}>
                      <TableCell className="font-medium">{beverage.name}</TableCell>
                      <TableCell className="text-right">
                        <Badge variant={(beverage.stock || 0) < 10 ? 'destructive' : 'outline'}>
                          {beverage.stock || 0} {beverage.unit || 'unidades'}
                        </Badge>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </div>
        </div>
        <DialogFooter className="grid grid-cols-1 sm:grid-cols-3 gap-2">
          <div className="flex gap-2">
            <Button variant="outline" onClick={handlePrint}>
              <Printer className="mr-2 h-4 w-4" /> Imprimir
            </Button>
            <Button variant="outline" onClick={handleDownloadPdf}>
              <Download className="mr-2 h-4 w-4" /> PDF
            </Button>
          </div>
          <Button variant="outline" onClick={() => onOpenChange(false)} className="sm:col-start-2">
            Cancelar
          </Button>
          <Button variant="destructive" onClick={() => onConfirm(inventory)}>
            Confirmar Cierre
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
