-- AlterTable
ALTER TABLE "Order" ADD COLUMN "masajistaIds" TEXT;
