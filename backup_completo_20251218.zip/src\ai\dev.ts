import { config } from 'dotenv';
config();

import '@/ai/flows/generate-sales-report-with-insights.ts';