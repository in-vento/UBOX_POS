import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function PUT(
    request: Request,
    { params }: { params: { id: string } }
) {
    try {
        const id = params.id;
        const body = await request.json();
        const { status, payment } = body;

        const updateData: any = {};
        if (status) updateData.status = status;

        // If payment is provided, add it and update paidAmount
        if (payment) {
            const order = await prisma.order.findUnique({ where: { id } });
            if (!order) throw new Error('Order not found');

            updateData.paidAmount = { increment: payment.amount };
            updateData.payments = {
                create: {
                    amount: payment.amount,
                    method: payment.method,
                    cashier: payment.cashier
                }
            };

            // Auto-complete if fully paid
            if ((order.paidAmount + payment.amount) >= order.totalAmount) {
                updateData.status = 'Completed';

                // Deduct stock when order is completed
                const orderWithItems = await prisma.order.findUnique({
                    where: { id },
                    include: { items: true }
                });

                if (orderWithItems) {
                    // Update stock for each product in the order
                    for (const item of orderWithItems.items) {
                        await prisma.product.update({
                            where: { id: item.productId },
                            data: { stock: { decrement: item.quantity } }
                        });
                    }
                }
            }
        }

        const updatedOrder = await prisma.order.update({
            where: { id },
            data: updateData,
            include: {
                items: true,
                payments: true
            }
        });

        return NextResponse.json(updatedOrder);
    } catch (error) {
        console.error('Error updating order:', error);
        return NextResponse.json({ error: 'Failed to update order' }, { status: 500 });
    }
}

export async function DELETE(
    request: Request,
    { params }: { params: { id: string } }
) {
    try {
        const id = params.id;

        // Delete the order and cascade delete will handle items and payments
        await prisma.order.delete({
            where: { id }
        });

        return NextResponse.json({ success: true, message: 'Order deleted successfully' });
    } catch (error) {
        console.error('Error deleting order:', error);
        return NextResponse.json({ error: 'Failed to delete order' }, { status: 500 });
    }
}
